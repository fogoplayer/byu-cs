/**
 * Zarin Loosli - 7/28/21
**/
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <limits>

#include "Maze.h"

using namespace std;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

/*------------------------------------------------ Function Declarations ------------------------------------------------*/

/**
 * main
 * @param int argc the number of arguments passed to main
 * @param int char* argv[] the file address | input file | output file
**/
int main(int argc, char *argv[])
{
    VS_MEM_CHECK
    // Inputs -------------------------------------------------------------------------------------------------------------
    // Check number of inputs
    if (argc < 3)
    {
        cerr << "Please provide name of input and output files";
        return 1;
    }
    // Try to open input file
    cout << "Input file: " << argv[1] << endl;
    std::ifstream in(argv[1]);
    if (!in)
    {
        cerr << "Unable to open " << argv[1] << " for input";
        return 2;
    }
    // Try to open output file
    cout << "Output file: " << argv[2] << endl;
    std::ofstream out(argv[2]);
    if (!out)
    {
        in.close();
        cerr << "Unable to open " << argv[2] << " for output";
        return 3;
    }

    // Top row (dimensions)
    int height;
    int width;
    int layerCount;
    in >> height >> width >> layerCount;

    // in.ignore((numeric_limits<int>::max(), '\n')); // For some reason after ignore, in contains an empty string before moving on to the next line. It's not in the input file, so IDK where it's coming from

    // Create and solve maze
    Maze maze(height, width, layerCount, in);
    out << "Solve Maze:" << endl;
    out << maze << endl;
    if (maze.find_maze_path())
    {
        out << "Solution:" << endl;
        out << maze << endl;
    }
    else
    {
        out << "No Solution Exists!";
    }

    return 0;
}

/*------------------------------------------------ Function Definitions ------------------------------------------------*/
